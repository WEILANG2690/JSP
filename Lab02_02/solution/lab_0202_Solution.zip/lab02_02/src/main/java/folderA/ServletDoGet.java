﻿package folderA;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/ServletDoGet.do")
public class ServletDoGet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void DoGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 RequestDispatcher rd = request.getRequestDispatcher("/folderA/successC.jsp");
	     rd.forward(request, response);
	     return ; 
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 RequestDispatcher rd = request.getRequestDispatcher("/folderA/successC.jsp");
	     rd.forward(request, response);
	     return ; 
	}
}
